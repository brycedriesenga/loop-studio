import {build} from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
const root=path.dirname(new URL(import.meta.url).pathname);
const pixel=await build({entryPoints:[path.join(root,'pixels.js')],bundle:true,format:'iife',minify:true,write:false,target:'es2020'});
const app=await build({entryPoints:[path.join(root,'app.js')],bundle:true,format:'iife',minify:true,write:false,target:'es2020',legalComments:'inline'});
let html=await fs.readFile(path.join(root,'shell.html'),'utf8');
let licenses='';for(const name of ['gifsicle-wasm-browser','gifuct-js','gifenc','js-binary-schema-parser']){const modules=await fs.access(path.join(root,'node_modules',name)).then(()=>path.join(root,'node_modules')).catch(()=>path.join(root,'../node_modules'));const dir=path.join(modules,name);const files=await fs.readdir(dir);const file=files.find(f=>/^license/i.test(f));licenses+=`\n\n${name}\n${file?await fs.readFile(path.join(dir,file),'utf8'):'See the package repository for license information.'}`;}
licenses+='\n\nGifsicle 1.92 copyright Eddie Kohler and contributors. Gifsicle is distributed under GNU GPL version 2 or later. GIF lossy compression copyright Kornel Lesiński. Source: https://github.com/kohler/gifsicle/tree/v1.92 ; browser build source: https://github.com/renzhezhilu/gifsicle-wasm-browser . The included minified scripts retain library notices. Unbundled editor source and upstream engine source are supplied in Loop-Studio-source.zip.\n\n'+await fs.readFile(path.join(root,'LICENSE'),'utf8');
const demo=(await fs.readFile(path.join(root,'sample.gif'))).toString('base64');
const script=app.outputFiles[0].text.replace('__DEMO__',demo).replace(/<\/script/gi,'<\\/script');
html=html.replace('/*__CSS__*/',await fs.readFile(path.join(root,'style.css'),'utf8')).replace('__PIXELS__',Buffer.from(pixel.outputFiles[0].text).toString('base64')).replace('__LICENSES__',licenses.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))).replace('/*__APP__*/',()=>script);
await fs.writeFile(path.join(root,'dist/index.html'),html);await fs.writeFile(path.join(root,'Loop-Studio.html'),html);console.log(`Built self-contained HTML: ${(Buffer.byteLength(html)/1024).toFixed(0)} KiB`);
