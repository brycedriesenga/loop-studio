# Loop Studio 2.1.0

A self-contained GIF editor for a digital design team. Open **Loop-Studio.html** in a current browser. No installation, account, server, CDN, or internet connection is required. Files are processed on the device. The HTML's Content Security Policy blocks connections to external servers. Named presets and the theme preference persist locally; image data and render history clear when the page closes.

## Build identification

The header and browser title show **v2.1.0**. The downloadable release is named **Loop-Studio-v2.1.0.html** to distinguish it from earlier attachments. It includes the v2 comparison modes, live edits, visual frame editor, size estimates, themes and pinned mobile preview.

## Use

1. Open a GIF, drag it onto the editor, paste a GIF file, or try the bundled sample.
2. Combine settings across the tools. Live edits show geometry, color, text, frame order, and timing before compression.
3. Choose Single, Side by side, or Wipe to compare the original and processed animation. Drag the wipe handle or focus the slider and use arrow keys.
4. Render to create a downloadable GIF. Results retains the last eight renders, with actual sizes and percentage savings or increases. Download uses the selected render.
5. Export/import settings to share a repeatable setup. Use undo/redo to revisit edits.

In comparison views both animations share elapsed time but retain their own frame timings. The comparison preview loops even if export is set to play once. Compression artifacts and palette reduction appear in the rendered result, not the live preview. Browser preview resampling approximates the chosen export filter. Changes always start from the original source and do not alter an existing result until another render completes.

## Saved presets and settings history

Open **Presets** to save the current settings under a name. Apply a preset, edit settings in any tool, then return to **Update from current**. Rename and Delete are available, and **Undo preset change** restores the previous preset collection after a save/update/rename/delete/import. Up to 50 presets are supported. Presets contain settings and captions, never GIF image bytes.

By default, saved presets omit exact frame edits (trim range, custom sequence, individual delay overrides and removed frame numbers). Enable **Include exact frame edits** to store those too. Applying a preset fits its settings to the current GIF and reports adjustments.

Preset collections can be exported/imported as JSON for backups, team sharing or moving to a newer HTML download. Import merges presets and adds a numeric suffix to duplicate names, preserving existing items. The older single-settings export/import is also retained.

Presets use localStorage. Local-file storage behavior varies by browser and may be tied to the file's exact path. Keep the editor at a consistent name/location; export presets before moving to a new file or browser. If browser storage is blocked or full, presets remain available for the current tab, with a clear session-only notice and export available. See [MDN localStorage](https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage).

Replacing a source keeps compression, output dimensions, crop, global speed/loop, automatic frame reduction/order, effects and captions where valid. Crop and trim ranges are fitted to the new canvas/frames. Aspect-locked output uses the new source proportions. Source-specific manual frame reordering, removals and individual delays are cleared. Incompatible timing is reset and output dimensions respect processing limits; adjustments are announced. Render history and settings undo history restart for each source.

**Undo**, **Redo**, and **Reset all** remain visible below settings on desktop and mobile. The frame editor also has Undo/Redo. Reset returns editor settings to defaults, keeps saved presets/renders, and is undoable. Shortcuts outside text/number/select inputs: Ctrl/Cmd+Z, Ctrl/Cmd+Shift+Z, and Ctrl+Y. Up to 40 settings snapshots are kept during a source session.

## Frame editing

Open **Timing & frames → Edit frames visually** for the output sequence, with a thumbnail for every frame. Click a thumbnail to inspect it. Edit delays in milliseconds, select frames for batch timing or deletion, drag a handle to reorder, or use the move buttons and left/right arrow keys on a handle. Reverse order and Original order are available.

A manual frame edit creates a custom sequence, replacing automatic trim, frame reduction, removal, delay overrides, and reverse/bounce settings. Global speed and loop settings still apply. Delay fields show timings before global speed. Thumbnails show source frames; the pinned live preview includes image edits. Original order restores every source frame and its delay.

## Size feedback and appearance

Small outputs (up to 9 million frame pixels and 90 frames) are fully encoded in the background using the export engine. Their calculated size can be reused when rendering. Larger outputs use short frame blocks spread through the animation, encoded with current settings, then extrapolated to a broad range. Very large outputs may require an explicit render. Sampled sizes are estimates, not bounds or guarantees; content and inter-frame optimization affect the final result. Target-size search runs only when Render is pressed.

Choose System, Light, or Dark in the header. On narrow screens, the preview and export actions stay pinned while the tool strip and settings scroll separately. The frame editor has its own pinned preview and scrolling grid.

## Coverage and research

Ezgif's workflows were reviewed through its official [optimizer](https://ezgif.com/optimize), [resizer](https://ezgif.com/resize), and [timing documentation](https://ezgif.com/speed). Compression options were checked against the [Gifsicle manual](https://www.lcdf.org/gifsicle/man.html) and the browser build's [API documentation](https://github.com/renzhezhilu/gifsicle-wasm-browser). This is an independent implementation, not an Ezgif mirror.

| Workflow | Loop Studio implementation |
| --- | --- |
| Lossy compression | Real Gifsicle lossy LZW, 0–200; 0 disables lossiness |
| Color reduction | Preserve source palettes or reduce to 2–256 colors |
| Dithering | Floyd–Steinberg, ordered, ordered 4×4/8×8, or none |
| Unchanged image data | O1 changed rectangles or O3 transparency optimization |
| Duplicate frames | Merge identical consecutive frames and their durations; optional preservation |
| Coalescing | Full-frame compatibility export via compositing and exact palettes where possible |
| Resize | Explicit dimensions, aspect lock, percentage shortcuts, six resampling methods |
| Crop, rotate, flip | Numeric crop coordinates; 90° increments; horizontal/vertical reflection |
| Frame reduction | Keep every 2nd/3rd/4th/5th/10th frame, optionally preserving duration |
| Timing | Visual frame grid, individual/batch delays, drag reorder, delete, trim, speed, reverse, bounce, loop count |
| Effects and text | Brightness, contrast, saturation, grayscale, sepia, inversion, matte, multi-line caption |
| Compare and export | Single/side/wipe previews, live edits, exact rendered sizes and percentage changes, three-preset comparison, GIF/current-frame PNG |
| Size estimates | Full background encoding for small files; sampled range for larger files |
| Target size | Best-effort candidate search using stronger lossiness and fewer colors |

Compression decisions involve tradeoffs: smaller dimensions reduce detail; fewer frames reduce motion smoothness; fewer colors can cause banding; dithering can smooth gradients while increasing size; lossiness can introduce artifacts. The target-size search does not automatically change dimensions or duration, and does not guarantee a target can be met.

The Quality preset uses lossiness 0 and preserves source palettes. With unchanged geometry/timing/effects it preserves rendered pixels. Resizing changes pixels. Text/effects build a new palette; recomposed frames with more than 256 displayed colors also require quantization. GIF delays use 10 ms increments and are clamped to at least 20 ms when timing changes. Source delays of 0/10 ms are interpreted as 100 ms for common browser playback behavior. Repeat counts are additional plays.

This focuses on GIF editing. It does not provide video conversion, multi-image GIF creation, APNG/WebP export, overlays, or Ezgif's full converter suite. Limits: 50 MB input, 4,096 px maximum width/height, 1,500 frames, 180 million canvas pixels across frames. Available browser memory may impose a lower practical limit. Browser policies can restrict local scripts and downloads.

## Build and maintain

The source package includes the editor modules, sample and test fixtures, pinned dependency versions, and third-party source archives. Run:

```sh
npm ci
npm run build
npm test
```

`build.mjs` bundles the browser workers, WASM engine, CSS, credits, and sample into `Loop-Studio.html` and `dist/index.html`. No external runtime assets are requested. `processor.js` handles rendering, estimates and cancellation; `preview.js` handles synchronized comparisons; `frame-editor.js` handles the visual sequence; `image-ops.js` shares pixel operations between live preview and export; `settings.js` validates/adapts settings and stores presets; `presets-ui.js` provides the preset manager.

Each Gifsicle invocation runs in a fresh worker because engine option state can otherwise persist between commands. Frame selection first composites optimized source frames, respecting background and previous disposal. Exact colors are preserved when a composited frame fits a GIF palette. Full frames are composed before frame deletion/reordering so dependent source patches remain correct.

## Validation

See VALIDATION.md for browser checks, measured estimate accuracy, pipeline checks and limitations. Automated tests use Node workers and a test-only canvas dependency to exercise the actual WASM/processing code. Chrome was used for visual and interaction checks; other browser engines and physical mobile devices were not separately verified.

## Licensing

Editor code is provided under GPL-2.0-or-later, without warranty. See LICENSE. Third-party notices are retained in the HTML's Guide and in the supplied source archives. Gifsicle is GPL-2.0-or-later; gifsicle-wasm-browser's wrapper is MIT; gifuct-js, js-binary-schema-parser and gifenc retain their upstream licenses. `third-party` contains upstream Gifsicle 1.92 C source and browser build source for maintainers.
