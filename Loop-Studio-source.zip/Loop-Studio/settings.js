import {cleanConfig,framePlan} from './model.js';

// Preserve useful settings while keeping them valid for the destination GIF.
export function fitConfig(input,meta,{newSource=false,previousMeta=null}={}){
 const cfg=cleanConfig(input),notes=[],count=meta.frames.length;
 if(newSource&&(cfg.sequence.length||cfg.remove||cfg.delays)){cfg.sequence=[];cfg.remove='';cfg.delays='';notes.push('Frame-specific edits cleared');}
 if(previousMeta&&cfg.end===previousMeta.frames.length)cfg.end=0;
 const start=cfg.start,end=cfg.end;
 if(cfg.start>count){cfg.start=1;cfg.end=0;}else if(cfg.end)cfg.end=Math.max(cfg.start,Math.min(count,cfg.end));
 if(start!==cfg.start||end!==cfg.end)notes.push('Trim range fitted');
 if(cfg.sequence.length){const valid=cfg.sequence.filter(f=>f.i<count);if(valid.length!==cfg.sequence.length)notes.push('Unavailable source frames skipped');cfg.sequence=valid;}
 if(!cfg.crop){cfg.x=0;cfg.y=0;cfg.cropW=meta.width;cfg.cropH=meta.height;}
 else {const old=[cfg.x,cfg.y,cfg.cropW,cfg.cropH].join();cfg.cropW=Math.min(meta.width,cfg.cropW||meta.width);cfg.cropH=Math.min(meta.height,cfg.cropH||meta.height);cfg.x=Math.min(cfg.x,meta.width-cfg.cropW);cfg.y=Math.min(cfg.y,meta.height-cfg.cropH);if(old!==[cfg.x,cfg.y,cfg.cropW,cfg.cropH].join())notes.push('Crop fitted to canvas');}
 let w=cfg.crop?cfg.cropW:meta.width,h=cfg.crop?cfg.cropH:meta.height;if(cfg.rotate%180)[w,h]=[h,w];
 if(cfg.lock&&cfg.width&&cfg.height){const height=Math.max(1,Math.round(cfg.width*h/w));if(height!==cfg.height){cfg.height=height;notes.push('Aspect ratio updated');}}
 let plan;try{plan=framePlan(meta,cfg);}catch{Object.assign(cfg,{start:1,end:0,step:1,order:'forward',remove:'',delays:'',sequence:[],speed:100});plan=framePlan(meta,cfg);notes.push('Incompatible frame timing reset');}
 const ow=cfg.width||(cfg.height?Math.max(1,Math.round(w*cfg.height/h)):w),oh=cfg.height||(cfg.width?Math.max(1,Math.round(h*cfg.width/w)):h);
 const scale=Math.min(1,4096/ow,4096/oh,Math.sqrt(180000000/(ow*oh*plan.length)));
 if(scale<1){cfg.width=Math.max(1,Math.floor(ow*scale));cfg.height=Math.max(1,Math.floor(oh*scale));notes.push('Output size fitted to processing limits');}
 return {settings:cfg,notes};
}

export const PRESETS_KEY='loop-studio-user-presets-v1';
const MAX_PRESETS=50,MAX_BYTES=4000000;
const id=()=>typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2);
const nameOf=value=>{if(typeof value!=='string'||!value.trim()||value.trim().length>60)throw Error('Use a preset name between 1 and 60 characters.');return value.trim();};
const presetSettings=(settings,includeFrames)=>{const cfg=cleanConfig(settings);if(!includeFrames)Object.assign(cfg,{sequence:[],remove:'',delays:'',start:1,end:0});return cfg;};
export class PresetStore {
 constructor(storage){this.storage=storage;this.items=[];this.persisted=true;this.previous=null;this.warning='';this.reload();}
 reload(){try{const raw=this.storage?.getItem(PRESETS_KEY);if(raw){const data=JSON.parse(raw);if(data.app!=='Loop Studio'||data.kind!=='presets'||data.version!==1||!Array.isArray(data.presets)||data.presets.length>MAX_PRESETS)throw Error('Invalid preset data');this.items=data.presets.map(p=>({id:typeof p.id==='string'?p.id.slice(0,100):id(),name:nameOf(p.name),includeFrames:p.includeFrames===true,settings:presetSettings(p.settings,p.includeFrames===true)}));}else this.items=[];this.persisted=!!this.storage;this.warning='';}catch{this.persisted=false;this.warning='Browser presets could not be loaded. You can import a backup or save presets for this session.';}return this.items;}
 commit(items,{remember=true}={}){if(items.length>MAX_PRESETS)throw Error('You can save up to 50 presets. Export a backup before removing any.');const text=JSON.stringify({app:'Loop Studio',kind:'presets',version:1,presets:items});if(text.length>MAX_BYTES)throw Error('The preset collection is too large. Exclude exact frame edits or keep fewer presets.');if(remember)this.previous=this.items;this.items=items;try{if(!this.storage)throw Error('No storage');this.storage.setItem(PRESETS_KEY,text);this.persisted=true;this.warning='';}catch{this.persisted=false;}return this.persisted;}
 uniqueName(name,except=null){name=nameOf(name);if(this.items.some(p=>p.id!==except&&p.name.toLowerCase()===name.toLowerCase()))throw Error('That preset name is already saved. Update it or choose another name.');return name;}
 create(name,settings,includeFrames=false){const item={id:id(),name:this.uniqueName(name),settings:presetSettings(settings,includeFrames),includeFrames};return {item,persisted:this.commit([item,...this.items])};}
 update(key,settings,includeFrames){const old=this.items.find(p=>p.id===key);if(!old)throw Error('This preset is no longer available.');const item={...old,includeFrames,settings:presetSettings(settings,includeFrames)};return {item,persisted:this.commit(this.items.map(p=>p.id===key?item:p))};}
 rename(key,name){name=this.uniqueName(name,key);return this.commit(this.items.map(p=>p.id===key?{...p,name}:p));}
 remove(key){return this.commit(this.items.filter(p=>p.id!==key));}
 undoChange(){if(!this.previous)return this.persisted;const old=this.previous;this.previous=null;return this.commit(old,{remember:false});}
 export(){return {app:'Loop Studio',kind:'presets',version:1,presets:this.items};}
 import(data){if(data.app!=='Loop Studio'||data.kind!=='presets'||data.version!==1||!Array.isArray(data.presets)||!data.presets.length)throw Error('Choose a Loop Studio preset collection JSON file.');if(data.presets.length+this.items.length>MAX_PRESETS)throw Error('Import would exceed the limit of 50 presets.');const names=new Set(this.items.map(p=>p.name.toLowerCase()));const imported=data.presets.map(p=>{const base=nameOf(p.name);let name=base,n=2;while(names.has(name.toLowerCase()))name=base.slice(0,52)+` (${n++})`;names.add(name.toLowerCase());if(!p.settings||typeof p.settings!=='object')throw Error('A preset has no valid settings.');return {id:id(),name,settings:presetSettings(p.settings,p.includeFrames===true),includeFrames:p.includeFrames===true};});return {count:imported.length,persisted:this.commit([...imported,...this.items])};}
}
