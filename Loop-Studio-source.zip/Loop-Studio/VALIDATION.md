# Loop Studio 2 validation

## Processing

- Gifsicle 1.92 WebAssembly was exercised in isolated workers through the app's commands. Each command receives a fresh worker to prevent persistent engine options from applying transformations twice.
- Existing pipeline checks passed for balanced/quality compression, resize, crop plus rotation, trim plus dropped frames, reverse, bounce, speed/loop, manual removals/delays, full frames, ordered dithering, caption and sepia.
- Prior decoded-pixel checks matched source RGB and alpha for lossless quality output. Transparent fixtures with background and previous disposal matched visible RGB over black/white backgrounds and alpha after quality, full-frame and reversed exports.
- New v2 tests verified a full background calculation exactly matches an explicit render: 304,784 bytes.
- Sampled estimate at 840 × 840: 9/30 frames, estimate 1,015,997 bytes, displayed range 609,598–1,422,395 bytes; actual render 956,219 bytes. This is one fixture, not a general accuracy guarantee.
- Custom sequence export retained three reordered source frames and delays of 250/50/20 ms at 200% speed, 320 ms total.
- Missing custom source frames were rejected and cancelled background processing stopped cleanly.

## Browser interactions

Chrome desktop viewport: 1363 × 936. Responsive tests used same-origin iframes at 390 × 844 and 768 × 844 so real CSS media queries applied.

- Sample open, original/processed single view, side by side, wipe slider, seeking and playback worked. The wipe slider also responded to Home/arrow keys.
- Live grayscale, geometry and speed updates appeared before rendering; 200% playback updated the displayed duration without pressing Render. Live/export effects share pixel math. Palette quantization and compression remain render-only.
- Light and dark modes were inspected. System/light/dark selection persists independently of file data.
- Frame grid displayed all 30 thumbnails. Individual delay changes persisted immediately through reordering and deletion. Mouse pointer drag, move buttons and keyboard arrows changed order. Mobile-width delay editing and move buttons preserved the edited timing.
- Selected-frame timing stayed selected after an individual delay edit; applying a batch delay changed only the selected frame. No application errors appeared in the browser log (extension metadata errors were unrelated).
- Changing the first 70 ms frame to 500 ms and deleting another 70 ms frame produced 29 frames and a 2.36 s exported duration, as expected.
- Footer and Results displayed both reductions and growth: observed 36.3% smaller and 100.4% larger outputs. GIF download emitted an actual browser download.
- On the 390 px layout the document width and scroll width were both 390 px. After scrolling to the target-size field, the preview stage remained at y=127 with height 194.27 px. Settings scroll independently; header, preview and export bar remain visible.
- The mobile Frames dialog filled its 390 × 844 viewport with a pinned preview and scrolling two-column frame grid.
- Existing v1 browser checks covered caption editing, three-preset comparison, history selection, best-effort target failure reporting and PNG download.

## Visual review

V2 concept: `/workspace/scratch/4641e3d324a5/generated_images/exec-895714b2-d650-45b6-906f-c36f3e5a5658.png`.

The concept and actual browser renders were visually inspected. The cloud browser exposes screenshots inline rather than as a local path; a separate view_image pass of the final screenshot was unavailable through that surface. Review used the actual viewport above rather than the concept's native dimensions.

| Area | Final result |
| --- | --- |
| Layout | Header, compact tool rail, settings inspector, dominant preview and fixed result bar. Results is a dedicated tool. |
| Palette | Flat graphite and neutral light surfaces, restrained orange accent, thin gray rules, green savings and amber increases. |
| Typography | System sans-serif, clear hierarchy, compact desktop labels; 16 px mobile inputs avoid focus zoom. |
| Components | Thin icons, segmented comparison modes, simple range controls, small radii, no physical-hardware textures or effects. |
| Preview | Actual synchronized canvas animation. The procedural sample ribbon intentionally differs from the concept's static artwork. |
| Mobile | Preview stays pinned while settings scroll; tool strip is horizontal; frame editor has its own pinned preview. |
| Copy | Live preview is explicitly labeled before compression; calculated/sampled sizes and rendered results are distinguished. |

## Limits of verification

- Chrome was checked. Safari, Firefox, Edge, physical touch devices, native software keyboards and direct file:// opening were not separately automated.
- The single HTML uses embedded assets and blob workers; normal use requires no web server. Local-script/download policies can still vary by workplace and browser.
- Sample estimates extrapolate selected frame blocks and may differ materially from export. Their displayed range is heuristic, not a statistical confidence interval.
- Live preview uses browser resampling and a capped preview resolution; final GIF compression and palette reduction are visible after rendering.
- Comparison playback deliberately loops regardless of the export repeat setting. Each animation keeps its own timing, so speed/frame edits need not show matching source frames at the same time.
- Large animations remain constrained by browser memory and the editor's documented input/output limits.

## v2.0.1 delivery check

The previously saved v2 HTML and ZIP were downloaded again and byte-checked. Their HTML matched the tested v2 build (SHA-256 0ff3ec6d3310253815301f5c8ea96412c634ae3d68e20b317d246ce1e1106c24). The user reported seeing an older attachment; that path could not be reproduced in the test browser. Release 2.0.1 adds an always-visible header version, a versioned browser title and a distinct download filename. No processing behavior changed.

Chrome verified the v2.0.1 title, version label, sample load, Wipe mode and 30-frame editor. No relevant application warnings or errors appeared. The version label fit at 390 px and 320 px widths with header scroll width equal to available width. Physical-device downloads and the ChatGPT client attachment path were not independently automated.

## v2.1.0 presets and workflow checks

`settings-test.mjs` passed persistence/reload, portable versus exact presets, duplicate-name rejection, update/rename, deletion recovery, import name conflicts, blocked/quota storage fallback and malformed JSON recovery. Source adaptation tests preserved compression, target size, speed and effects; fitted crop/locked aspect ratio/trim to a 320 × 180, 7-frame destination; skipped missing custom frames; and kept enlarged output within the 180 million pixel limit.

Chrome desktop (1363 × 936) interactions passed:

- Saved “Email · warm” with sepia and 150% speed, reset editor settings, then reapplied the preset.
- Settings Undo reverted the preset application; Redo restored sepia. Reset returned the effect to None; Undo restored it.
- Renamed to “Email · revised”, changed brightness to 120%, updated from current, reloaded the page, applied the saved preset before loading a GIF, and observed sepia/120% brightness after opening the sample.
- Replaced the loaded sample through Source while a custom frame delay was active. The replacement kept 150% speed, sepia, 120% brightness and Wipe view, while clearing the old custom sequence.
- Frame editor Undo restored a 70 ms delay after changing it to 500 ms; Redo restored 500 ms.
- Deleted a saved preset and recovered it with Undo preset change. Export presets produced an actual browser download.
- A render after these changes completed at 257.7 KB / 44.6% smaller. Browser logs had no relevant application errors or warnings.

At 390 × 844 and 320 × 740 responsive widths the layout fit without horizontal overflow. Undo, Redo and Reset all were visible on mobile; applying a saved preset, resetting and undoing worked. Both light and dark appearances were inspected. Notifications were positioned above the pinned history controls and made pointer-transparent. Existing preview/action pinning remains in effect.

The Browser extension execution tool was not exposed, so its documented cloud-browser fallback was used. Verification was on the internal local preview server; direct file-URL preset persistence, native mobile keyboards, physical touch devices and other browser engines were not separately automated. Local-file storage behavior is explicitly described in the editor and README, with export/import backups and session-only fallback.
