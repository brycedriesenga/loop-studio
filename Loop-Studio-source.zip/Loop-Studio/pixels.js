import {parseGIF,decompressFrame} from 'gifuct-js';
import {GIFEncoder,quantize,applyPalette} from 'gifenc';
import {inspectGIF} from './model.js';
import {adjustPixels,drawCaption,transformCanvas} from './image-ops.js';
class Compositor {
 constructor(buffer){this.meta=inspectGIF(buffer);this.gif=parseGIF(buffer);this.frames=this.gif.frames.filter(f=>f.image);this.canvas=new OffscreenCanvas(this.meta.width,this.meta.height);this.ctx=this.canvas.getContext('2d',{willReadFrequently:true});this.patch=new OffscreenCanvas(1,1);this.pc=this.patch.getContext('2d');this.reset();}
 reset(){this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);const f=this.frames[0];this.background=f.gce?.extras.transparentColorGiven?null:this.gif.gct?.[this.gif.lsd.backgroundColorIndex];if(this.background){this.ctx.fillStyle=`rgb(${this.background.join(',')})`;this.ctx.fillRect(0,0,this.canvas.width,this.canvas.height);}this.index=-1;this.previous=null;this.restore=null;}
 draw(n){if(n<this.index)this.reset();while(this.index<n){const prev=this.previous;if(prev?.disposalType===2){const d=prev.dims;this.ctx.clearRect(d.left,d.top,d.width,d.height);if(prev.transparentIndex===undefined&&this.background){this.ctx.fillStyle=`rgb(${this.background.join(',')})`;this.ctx.fillRect(d.left,d.top,d.width,d.height);}}
   if(prev?.disposalType===3&&this.restore)this.ctx.putImageData(this.restore,0,0);
   const f=decompressFrame(this.frames[++this.index],this.gif.gct,true);this.restore=f.disposalType===3?this.ctx.getImageData(0,0,this.canvas.width,this.canvas.height):null;
   this.patch.width=f.dims.width;this.patch.height=f.dims.height;this.pc.putImageData(new ImageData(f.patch,f.dims.width,f.dims.height),0,0);this.ctx.drawImage(this.patch,f.dims.left,f.dims.top);this.previous=f;
 }return this.canvas;}
}
let preview=null,original=null,live=null,result=null;
self.onmessage=async({data:m})=>{try{
 if(m.type==='pairLoad'){original=new Compositor(m.source);live=new Compositor(m.source);result=m.result?new Compositor(m.result):null;self.postMessage({type:'ready',id:m.id});}
 if(m.type==='pairFrame'){const a=await createImageBitmap(original.draw(m.originalFrame));let b;if(m.kind==='live')b=await createImageBitmap(transformCanvas(live.draw(m.sourceFrame),live.meta,m.cfg));else b=await createImageBitmap((result||original).draw(m.processedFrame));self.postMessage({type:'pair',original:a,processed:b,id:m.id},[a,b]);}
 if(m.type==='thumbnails'){const c=new Compositor(m.buffer),thumb=new OffscreenCanvas(128,88),t=thumb.getContext('2d');for(let i=0;i<c.frames.length;i++){t.clearRect(0,0,128,88);const scale=Math.min(128/c.meta.width,88/c.meta.height),w=c.meta.width*scale,h=c.meta.height*scale;t.drawImage(c.draw(i),(128-w)/2,(88-h)/2,w,h);const blob=await thumb.convertToBlob({type:'image/png'}),buffer=await blob.arrayBuffer();self.postMessage({type:'thumbnail',i,buffer},[buffer]);}self.postMessage({type:'thumbnailsDone'});}
 if(m.type==='load'){preview=new Compositor(m.buffer);self.postMessage({type:'ready',id:m.id});}
 if(m.type==='frame'){if(!preview)throw Error('Open a GIF first.');const bitmap=await createImageBitmap(preview.draw(m.frame));self.postMessage({type:'frame',bitmap,frame:m.frame,id:m.id},[bitmap]);}
 if(m.type==='sample'){
  const comp=new Compositor(m.buffer),cache=new Map(),enc=GIFEncoder();
  for(const i of [...new Set(m.plan.map(f=>f.i))].sort((a,b)=>a-b)){const canvas=transformCanvas(comp.draw(i),comp.meta,m.cfg,0),ctx=canvas.getContext('2d'),rgba=ctx.getImageData(0,0,canvas.width,canvas.height).data;const palette=quantize(rgba,255,{format:'rgb565'}),index=applyPalette(rgba,palette),ti=palette.length;palette.push([0,0,0]);let transparent=false;for(let k=0;k<index.length;k++)if(rgba[k*4+3]<128){index[k]=ti;transparent=true;}cache.set(i,{palette,index,ti,transparent,w:canvas.width,h:canvas.height});}
  for(const f of m.plan){const c=cache.get(f.i);enc.writeFrame(c.index,c.w,c.h,{palette:c.palette,transparent:c.transparent,transparentIndex:c.ti,delay:f.delay*10,dispose:2,repeat:0});}enc.finish();const bytes=enc.bytes();self.postMessage({type:'done',buffer:bytes.buffer},[bytes.buffer]);
 }
 if(m.type==='effects'){
  const comp=new Compositor(m.buffer),cfg=m.cfg,w=comp.meta.width,h=comp.meta.height,canvas=new OffscreenCanvas(w,h),ctx=canvas.getContext('2d',{willReadFrequently:true}),enc=GIFEncoder();
  for(let i=0;i<comp.frames.length;i++){
   ctx.clearRect(0,0,w,h);ctx.drawImage(comp.draw(i),0,0);const image=ctx.getImageData(0,0,w,h);adjustPixels(image.data,cfg);ctx.putImageData(image,0,0);
   if(cfg.matte!=='transparent'){ctx.globalCompositeOperation='destination-over';ctx.fillStyle=cfg.matte;ctx.fillRect(0,0,w,h);ctx.globalCompositeOperation='source-over';}
   drawCaption(ctx,cfg,w,h);const rgba=ctx.getImageData(0,0,w,h).data;let transparent=false;for(let k=3;k<rgba.length;k+=4)if(rgba[k]<128){transparent=true;break;}
   // Preserve exact colors whenever a composited frame fits in a GIF palette.
   let palette=[],index=new Uint8Array(w*h),map=new Map(),overflow=false,ti=0;
   for(let k=0;k<index.length;k++){const q=k*4,alpha=rgba[q+3]<128,key=alpha?-1:(rgba[q]<<16|rgba[q+1]<<8|rgba[q+2]);let ix=map.get(key);if(ix===undefined){ix=palette.length;if(ix===256){overflow=true;break;}map.set(key,ix);palette.push(alpha?[0,0,0]:[rgba[q],rgba[q+1],rgba[q+2]]);if(alpha)ti=ix;}index[k]=ix;}
   if(overflow){palette=quantize(rgba,transparent?255:256,{format:'rgb565'});if(!palette.length)palette.push([0,0,0]);index=applyPalette(rgba,palette);if(transparent){ti=palette.length;palette.push([0,0,0]);for(let k=0;k<index.length;k++)if(rgba[k*4+3]<128)index[k]=ti;}}
   enc.writeFrame(index,w,h,{palette,transparent,transparentIndex:ti,delay:Math.max(2,comp.meta.frames[i].delay)*10,dispose:2,repeat:comp.meta.loop});
   if(i%5===0)self.postMessage({type:'progress',value:(i+1)/comp.frames.length});
  }
  enc.finish();const bytes=enc.bytes();self.postMessage({type:'done',buffer:bytes.buffer},[bytes.buffer]);
 }
 }catch(e){self.postMessage({type:'error',message:e.message||String(e),id:m.id});}};
