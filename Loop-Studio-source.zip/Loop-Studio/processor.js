import gifsicle from 'gifsicle-wasm-browser';
import {prepCommands,finishCommand,needsPixels,framePlan,inspectGIF} from './model.js';
import {outputDimensions} from './image-ops.js';
const abortError=()=>new DOMException('Cancelled','AbortError');
export function createProcessor(pixelUrl){
 function task(url,message,signal,onProgress){return new Promise((resolve,reject)=>{
  if(signal?.aborted){reject(abortError());return;}const worker=new Worker(url);let finished=false;
  const complete=(error,value)=>{if(finished)return;finished=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);worker.terminate();error?reject(error):resolve(value);};
  const abort=()=>complete(abortError()),timer=setTimeout(()=>complete(Error('Processing took too long. Try fewer frames or smaller dimensions.')),180000);signal?.addEventListener('abort',abort,{once:true});
  worker.onmessage=({data:m})=>{if(m?.type==='progress'){onProgress?.(m.value);return;}if(m?.type==='done'){complete(null,m.buffer);return;}if(Array.isArray(m)&&m.length){const b=m[0].file;complete(null,b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength));return;}complete(Error(m?.message||(typeof m==='string'?m:'The GIF engine could not process this file.')));};
  worker.onerror=()=>complete(Error('The local GIF engine stopped. Try a smaller file.'));worker.postMessage(message);
 });}
 const cli=(input,command,signal)=>task(gifsicle.tool.worker(),{data:[{name:'input.gif',file:input}],command:[command],folder:[],isStrict:false},signal);
 async function prepare(input,meta,cfg,signal,onProgress){const p=prepCommands(meta,cfg);let data=input;
  if(cfg.crop||cfg.rotate||cfg.flipH||cfg.flipV||cfg.width||cfg.height)data=await cli(data,p.commands[0],signal);
  if(needsPixels(cfg)||p.normalize)data=await task(pixelUrl,{type:'effects',buffer:data,cfg},signal,onProgress);
  if(p.timing)data=await cli(data,p.commands[1],signal);return data;
 }
 async function render(input,meta,cfg,signal,onProgress){const data=await prepare(input,meta,cfg,signal,onProgress);return cli(data,finishCommand('input.gif',cfg),signal);}
 async function estimate(input,meta,cfg,signal){const plan=framePlan(meta,cfg),dims=outputDimensions(meta,cfg),pixels=dims.width*dims.height*plan.length;
  if(pixels<=9000000&&plan.length<=90){const buffer=await render(input,meta,{...cfg,target:0},signal);return {kind:'calculated',size:buffer.byteLength,buffer,frames:plan.length,total:plan.length};}
  const count=Math.min(plan.length,12,Math.floor(7000000/(dims.width*dims.height)));
  if(count<2)return {kind:'unavailable',reason:'Render for an accurate size at these dimensions.'};
  // Short adjacent blocks spread across the animation include several motion states.
  const positions=new Set();const blocks=Math.ceil(count/3);
  for(let k=0;k<blocks;k++){const start=Math.round(k*Math.max(0,plan.length-3)/Math.max(1,blocks-1));for(let j=0;j<3&&positions.size<count;j++)positions.add(Math.min(plan.length-1,start+j));}
  const sampled=[...positions].sort((a,b)=>a-b).map(i=>plan[i]);
  const raw=await task(pixelUrl,{type:'sample',buffer:input,cfg,plan:sampled},signal);const compressed=await cli(raw,finishCommand('input.gif',{...cfg,target:0}),signal);
  const checked=inspectGIF(compressed),overhead=Math.min(checked.size,850),size=Math.max(overhead,overhead+(checked.size-overhead)*plan.length/sampled.length);
  return {kind:'sampled',size,low:Math.max(overhead,Math.round(size*.6)),high:Math.round(size*1.4),frames:sampled.length,total:plan.length};
 }
 return {render,estimate,prepare,cli};
}
