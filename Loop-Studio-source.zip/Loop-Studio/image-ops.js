export function adjustPixels(data,cfg){const b=cfg.brightness/100,c=cfg.contrast/100,s=cfg.saturation/100;
 for(let i=0;i<data.length;i+=4){let r=data[i],g=data[i+1],bl=data[i+2];const l=.2126*r+.7152*g+.0722*bl;r=l+(r-l)*s;g=l+(g-l)*s;bl=l+(bl-l)*s;
  if(cfg.filter==='grayscale')r=g=bl=l;
  if(cfg.filter==='sepia'){const rr=r,gg=g;r=.393*rr+.769*gg+.189*bl;g=.349*rr+.686*gg+.168*bl;bl=.272*rr+.534*gg+.131*bl;}
  if(cfg.filter==='invert'){r=255-r;g=255-g;bl=255-bl;}
  data[i]=(r*b-128)*c+128;data[i+1]=(g*b-128)*c+128;data[i+2]=(bl*b-128)*c+128;
 }
}
export function drawCaption(ctx,cfg,w,h,scale=1){if(!cfg.text.trim())return;const pad=Math.max(8*scale,w*.04),size=Math.min(cfg.textSize*scale,h*.45);ctx.font=`600 ${size}px Arial, sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineJoin='round';ctx.lineWidth=Math.max(2*scale,size*.10);ctx.strokeStyle='rgba(0,0,0,.85)';ctx.fillStyle=cfg.textColor;
 const lines=[];for(const para of cfg.text.split('\n')){let line='';for(const word of para.split(' ')){const next=line?line+' '+word:word;if(ctx.measureText(next).width>w-pad*2&&line){lines.push(line);line=word;}else line=next;}lines.push(line);}
 const lh=size*1.2,total=lines.length*lh,top=cfg.textPosition==='top'?pad+lh/2:cfg.textPosition==='center'?(h-total)/2+lh/2:h-pad-total+lh/2;
 lines.forEach((line,i)=>{if(cfg.textStroke)ctx.strokeText(line,w/2,top+i*lh,w-pad*2);ctx.fillText(line,w/2,top+i*lh,w-pad*2);});
}
export function outputDimensions(meta,cfg){let w=cfg.crop?cfg.cropW:meta.width,h=cfg.crop?cfg.cropH:meta.height;if(cfg.rotate%180)[w,h]=[h,w];return {width:cfg.width||Math.max(1,Math.round(cfg.height?w*cfg.height/h:w)),height:cfg.height||Math.max(1,Math.round(cfg.width?h*cfg.width/w:h))};}
export function transformCanvas(source,meta,cfg,cap=900){const {width,height}=outputDimensions(meta,cfg),ratio=cap?Math.min(1,cap/Math.max(width,height)):1,w=Math.max(1,Math.round(width*ratio)),h=Math.max(1,Math.round(height*ratio));
 const canvas=new OffscreenCanvas(w,h),ctx=canvas.getContext('2d',{willReadFrequently:true});
 const sx=cfg.crop?cfg.x:0,sy=cfg.crop?cfg.y:0,sw=cfg.crop?cfg.cropW:meta.width,sh=cfg.crop?cfg.cropH:meta.height;
 ctx.save();ctx.translate(w/2,h/2);const rotated=cfg.rotate%180;ctx.scale(w/(rotated?sh:sw),h/(rotated?sw:sh));ctx.rotate(cfg.rotate*Math.PI/180);ctx.scale(cfg.flipH?-1:1,cfg.flipV?-1:1);ctx.imageSmoothingEnabled=cfg.method!=='sample';ctx.imageSmoothingQuality='high';ctx.drawImage(source,sx,sy,sw,sh,-sw/2,-sh/2,sw,sh);ctx.restore();
 const image=ctx.getImageData(0,0,w,h);adjustPixels(image.data,cfg);ctx.putImageData(image,0,0);
 if(cfg.matte!=='transparent'){ctx.globalCompositeOperation='destination-over';ctx.fillStyle=cfg.matte;ctx.fillRect(0,0,w,h);ctx.globalCompositeOperation='source-over';}
 drawCaption(ctx,cfg,w,h,ratio);return canvas;
}
