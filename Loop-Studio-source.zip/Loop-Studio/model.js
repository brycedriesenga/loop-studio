export const defaults = {
  preset:'balanced', lossy:35, colors:256, dither:'floyd-steinberg', optimize:3, duplicates:true, strip:true,
  width:0,height:0,lock:true,method:'lanczos3',crop:false,x:0,y:0,cropW:0,cropH:0,rotate:0,flipH:false,flipV:false,
  start:1,end:0,step:1,preserve:true,speed:100,order:'forward',loop:'keep',repeat:1,remove:'',delays:'',
  brightness:100,contrast:100,saturation:100,filter:'none',matte:'transparent',
  text:'',textSize:32,textColor:'#ffffff',textPosition:'bottom',textStroke:true,
  target:0, sequence:[]
};
export const presets={quality:{lossy:0,colors:0,dither:'floyd-steinberg'},balanced:{lossy:35,colors:256,dither:'floyd-steinberg'},smallest:{lossy:100,colors:128,dither:'none'}};
const ranges={lossy:[0,200],colors:[0,256],optimize:[0,3],width:[0,4096],height:[0,4096],x:[0,4095],y:[0,4095],cropW:[0,4096],cropH:[0,4096],rotate:[0,270],start:[1,1500],end:[0,1500],step:[1,10],speed:[10,400],repeat:[1,65535],brightness:[0,200],contrast:[0,200],saturation:[0,200],textSize:[8,200],target:[0,100000]};
const enums={preset:['custom','quality','balanced','smallest'],colors:[0,256,192,128,96,64,32,16,8,4,2],dither:['none','floyd-steinberg','ordered','o4','o8'],optimize:[0,1,3],step:[1,2,3,4,5,10],method:['sample','mix','catrom','mitchell','lanczos2','lanczos3'],rotate:[0,90,180,270],order:['forward','reverse','bounce'],loop:['keep','forever','once','repeat'],filter:['none','grayscale','sepia','invert'],matte:['transparent','#ffffff','#191919'],textPosition:['top','center','bottom']};
export function cleanConfig(input={}) {
  const out={...defaults};
  for(const k of Object.keys(defaults)){
    const v=input[k]; if(v===undefined)continue;
    if(k==='sequence'){if(Array.isArray(v)&&v.length<=1500)out.sequence=v.filter(f=>f&&Number.isInteger(f.i)&&f.i>=0&&f.i<1500&&Number.isFinite(f.delay)).map(f=>({i:f.i,delay:Math.max(2,Math.min(65535,Math.round(f.delay)))}));continue;}
    if(typeof defaults[k]==='boolean'){out[k]=v===true;continue;}
    if(ranges[k]){const n=Number(v);if(Number.isFinite(n))out[k]=Math.min(ranges[k][1],Math.max(ranges[k][0],k==='target'?n:Math.round(n)));}
    else if(typeof v==='string')out[k]=v.slice(0,k==='text'?300:10000);
    if(enums[k]&&!enums[k].includes(out[k]))out[k]=defaults[k];
  }
  if(!/^#[\da-f]{6}$/i.test(out.textColor))out.textColor=defaults.textColor;
  return out;
}
// Bounded structural validation before a decoder or the WASM engine sees a file.
export function inspectGIF(buffer) {
  const b=new Uint8Array(buffer), v=new DataView(buffer);let p=13;
  const need=n=>{if(p+n>b.length)throw Error('This GIF is incomplete or damaged. Try exporting it again.');};
  if(b.length<14||!['GIF87a','GIF89a'].includes(String.fromCharCode(...b.slice(0,6))))throw Error('Choose a GIF file. Other image and video formats are not supported in this editor.');
  const width=v.getUint16(6,true),height=v.getUint16(8,true);
  if(!width||!height||width>4096||height>4096||width*height>16777216)throw Error('This GIF is too large. The maximum canvas is 4096 × 4096 pixels.');
  if(b[10]&128){const n=3*(2**((b[10]&7)+1));need(n);p+=n;}
  let gce={delay:10},frames=[],loop=-1,pixels=0,trailer=false;
  function blocks(){const parts=[];while(true){need(1);const n=b[p++];if(!n)break;need(n);parts.push(b.subarray(p,p+n));p+=n;}return parts;}
  while(p<b.length){need(1);const marker=b[p++];
    if(marker===0x3b){trailer=true;break;}
    if(marker===0x21){need(1);const label=b[p++];const parts=blocks();
      if(label===0xf9&&parts[0]?.length===4){const a=parts[0];gce={delay:a[1]|a[2]<<8,disposal:(a[0]>>2)&7,transparent:!!(a[0]&1)};}
      if(label===0xff&&parts[0]&&/^(NETSCAPE|ANIMEXTS)/.test(String.fromCharCode(...parts[0]))&&parts[1]?.length>=3)loop=parts[1][1]|parts[1][2]<<8;
      continue;
    }
    if(marker!==0x2c)throw Error('This GIF contains an invalid block. Try exporting it again.');
    need(9);const x=v.getUint16(p,true),y=v.getUint16(p+2,true),w=v.getUint16(p+4,true),h=v.getUint16(p+6,true),flags=b[p+8];p+=9;
    if(!w||!h||x+w>width||y+h>height)throw Error('This GIF has frames outside its canvas. Re-export it with a consistent canvas size.');
    pixels+=width*height;
    if(frames.length>=1500||pixels>180000000)throw Error('This animation exceeds the local processing limit (1,500 frames / 180 million canvas pixels). Use a shorter or smaller export.');
    if(flags&128){const n=3*(2**((flags&7)+1));need(n);p+=n;}
    need(1);const min=b[p++];if(min<2||min>8)throw Error('Invalid GIF color encoding.');blocks();frames.push({...gce,x,y,width:w,height:h});gce={delay:10};
  }
  if(!frames.length||!trailer)throw Error('This GIF is incomplete or contains no frames.');
  return {width,height,frames,loop,duration:frames.reduce((a,f)=>a+displayDelay(f.delay),0),size:b.length};
}
export const displayDelay=cs=>cs<2?100:cs*10;
export function framePlan(meta,cfg) {
  if(cfg.sequence?.length){if(cfg.sequence.some(f=>f.i>=meta.frames.length))throw Error('The custom sequence contains a frame outside this GIF. Reset the sequence or open the matching GIF.');return cfg.sequence.map(f=>({i:f.i,delay:Math.max(2,Math.min(65535,Math.round(f.delay*100/cfg.speed)))}));}
  const count=meta.frames.length,start=cfg.start-1,end=(cfg.end||count)-1;
  if(start>end||start>=count||end>=count)throw Error(`Choose a valid trim range between frame 1 and ${count}.`);
  const removed=new Set();
  if(cfg.remove.trim())for(const segment of cfg.remove.split(',')){
    const m=segment.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);if(!m)throw Error('Remove frames using numbers or ranges, e.g. 2, 5-8.');
    const a=+m[1],z=+(m[2]||m[1]);if(a<1||z<a||z>count)throw Error(`Removed frame numbers must be between 1 and ${count}.`);
    for(let i=a;i<=z;i++)removed.add(i-1);
  }
  const overrides={};if(cfg.delays.trim())for(const s of cfg.delays.split(',')){
    const m=s.trim().match(/^(\d+)\s*:\s*(\d+)$/);if(!m||+m[1]<1||+m[1]>count||+m[2]<20||+m[2]>655350)throw Error('Frame delays use frame:milliseconds, e.g. 1:500, 12:200 (20–655350 ms).');overrides[+m[1]-1]=Math.round(+m[2]/10);
  }
  const valid=[];for(let i=start;i<=end;i++)if(!removed.has(i))valid.push(i);
  if(!valid.length)throw Error('Keep at least one frame.');
  const plan=[];
  for(let n=0;n<valid.length;n+=cfg.step){const i=valid[n];let cs=overrides[i]??(meta.frames[i].delay<2?10:meta.frames[i].delay);
    if(cfg.preserve)for(let k=1;k<cfg.step&&n+k<valid.length;k++){const j=valid[n+k];cs+=overrides[j]??(meta.frames[j].delay<2?10:meta.frames[j].delay);}
    const delay=Math.max(2,Math.round(cs*100/cfg.speed));if(delay>65535)throw Error('The chosen timing creates a frame longer than 655.35 seconds. Increase speed or reduce frame reduction.');plan.push({i,delay});
  }
  if(cfg.order==='reverse')plan.reverse();
  if(cfg.order==='bounce'&&plan.length>2)plan.push(...plan.slice(1,-1).reverse());
  if(plan.length>1500)throw Error('The output sequence exceeds 1,500 frames. Keep fewer frames before adding a bounce.');
  return plan;
}
export function prepCommands(meta,cfg){
  const plan=framePlan(meta,cfg),args=[];if(cfg.strip)args.push('--no-comments','--no-names');
  let w=meta.width,h=meta.height;
  if(cfg.crop){if(!cfg.cropW||!cfg.cropH||cfg.x+cfg.cropW>w||cfg.y+cfg.cropH>h)throw Error('Crop area must fit inside the original canvas.');args.push(`--crop=${cfg.x},${cfg.y}+${cfg.cropW}x${cfg.cropH}`);w=cfg.cropW;h=cfg.cropH;}
  if(cfg.rotate){args.push(`--rotate-${cfg.rotate}`);if(cfg.rotate%180)[w,h]=[h,w];}
  if(cfg.flipH)args.push('--flip-horizontal');if(cfg.flipV)args.push('--flip-vertical');
  const nw=cfg.width|| (cfg.height?Math.round(w*cfg.height/h):w),nh=cfg.height||(cfg.width?Math.round(h*cfg.width/w):h);
  if(nw>4096||nh>4096||nw*nh*plan.length>180000000)throw Error('Output exceeds the local processing limit. Choose smaller dimensions or fewer frames.');
  if(cfg.width||cfg.height)args.push(`--resize=${cfg.width||'_'}x${cfg.height||'_'}`,`--resize-method=${cfg.method}`);
  const commands=[`${args.join(' ')} input.gif -o /out/full.gif`];
  const timing=plan.length!==meta.frames.length||plan.some((f,i)=>f.i!==i||f.delay!==meta.frames[i]?.delay);
  if(timing)commands.push(`input.gif ${plan.map(f=>`--delay=${f.delay} #${f.i}`).join(' ')} -o /out/timed.gif`);
  const normalize=plan.length!==meta.frames.length||plan.some((f,i)=>f.i!==i)||cfg.optimize===0;
  return {commands,name:'input.gif',plan,timing,normalize};
}
export function finishCommand(name,cfg,out='result'){
  const a=cfg.optimize?[`-O${cfg.optimize}`]:[];
  if(cfg.optimize&&!cfg.duplicates)a.push('-Okeep-empty');
  if(cfg.lossy)a.push(`--lossy=${cfg.lossy}`);
  if(cfg.colors)a.push(`--colors=${cfg.colors}`,cfg.dither==='none'?'--no-dither':`--dither=${cfg.dither}`,'--color-method=blend-diversity');
  if(cfg.strip)a.push('--no-comments','--no-names');
  if(cfg.loop==='forever')a.push('--loopcount=0');else if(cfg.loop==='once')a.push('--no-loopcount');else if(cfg.loop==='repeat')a.push(`--loopcount=${cfg.repeat}`);
  return `${a.join(' ')} ${name} -o /out/${out}.gif`;
}
export const needsPixels=c=>c.filter!=='none'||c.brightness!==100||c.contrast!==100||c.saturation!==100||c.text.trim()||c.matte!=='transparent';
