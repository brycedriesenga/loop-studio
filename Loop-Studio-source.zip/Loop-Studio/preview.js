import {framePlan,displayDelay} from './model.js';
import {outputDimensions} from './image-ops.js';
const locate=(frames,time)=>{let total=frames.reduce((a,f)=>a+f.delay,0)*10;if(!total)return 0;let t=time%total;for(let i=0;i<frames.length;i++){t-=frames[i].delay*10;if(t<0)return i;}return frames.length-1;};
const naturalFrames=meta=>meta.frames.map((f,i)=>({i,delay:displayDelay(f.delay)/10}));
export class Preview {
 constructor(url,el,onState){this.url=url;this.el=el;this.onState=onState;this.time=0;this.playing=false;this.layout='single';this.single='original';this.liveEnabled=true;this.generation=0;this.lastKey='';this.busy=false;this.ready=false;this.queued=false;this.wipe=50;this.resizeObserver=new ResizeObserver(()=>this.paint());this.resizeObserver.observe(el.stage);}
 configure(source,result,cfg,{forceLive=false}={}){this.cfg=cfg;this.configKey=JSON.stringify(cfg);this.forceLive=forceLive;const changedSource=this.source!==source,changedResult=this.result!==result;this.source=source;this.result=result;
  if(!source)return;this.plan=framePlan(source.meta,cfg);this.originalFrames=naturalFrames(source.meta);this.kind=(forceLive||this.liveEnabled&&(!result||result.fingerprint!==JSON.stringify(cfg)))?'live':result?'render':'original';
  this.processFrames=this.kind==='live'?this.plan:this.kind==='render'?naturalFrames(result.meta):this.originalFrames;
  this.processDimensions=this.kind==='live'?outputDimensions(source.meta,cfg):this.kind==='render'?result.meta:source.meta;
  this.duration=(this.layout==='single'&&this.single==='original'?source.meta.duration:this.processFrames.reduce((a,f)=>a+f.delay,0)*10);
  this.time=Math.min(this.time,Math.max(0,this.duration-1));
  if(changedSource||changedResult||!this.worker){this.worker?.terminate();this.generation++;this.ready=false;this.busy=false;this.lastKey='';this.worker=new Worker(this.url);const id=this.generation;
   this.worker.onmessage=({data:m})=>{if(id!==this.generation){m.original?.close();m.processed?.close();return;}if(m.type==='ready'){this.ready=true;this.request(true);}if(m.type==='pair'){this.busy=false;this.bitmaps?.original.close();this.bitmaps?.processed.close();this.bitmaps={original:m.original,processed:m.processed};this.paint();if(this.queued){this.queued=false;this.request(true);}}if(m.type==='error'){this.busy=false;this.pause();this.onState({error:m.message});}};
   this.worker.onerror=()=>{this.busy=false;this.pause();this.onState({error:'Preview failed. Try a smaller GIF or another current browser.'});};this.worker.postMessage({type:'pairLoad',source:source.buffer,result:result?.buffer,id});
   if(changedSource){this.time=0;this.pause();}
  }
  this.request(true);this.status();
 }
 setLayout(layout){this.layout=layout;this.el.stage.dataset.layout=layout;this.reconfigure();}
 reconfigure(){if(this.source)this.configure(this.source,this.result,this.cfg,{forceLive:this.forceLive});else this.el.stage.dataset.layout=this.layout;}
 seek(ms){this.pause();this.time=Math.max(0,Math.min(this.duration-1,ms));this.request(true);this.status();}
 seekFrame(index){const frames=this.layout==='single'&&this.single==='original'?this.originalFrames:this.processFrames;this.seek(frames.slice(0,index).reduce((a,f)=>a+f.delay*10,0));}
 play(){if(!this.source||!this.ready)return;this.playing=true;if(this.time>=this.duration-1)this.time=0;this.baseTime=performance.now()-this.time;cancelAnimationFrame(this.raf);this.tick();this.status();}
 pause(){this.playing=false;cancelAnimationFrame(this.raf);this.status();}
 tick(){if(!this.playing)return;this.time=(performance.now()-this.baseTime)%Math.max(1,this.duration);this.request();this.status();this.raf=requestAnimationFrame(()=>this.tick());}
 status(){if(!this.source)return;const frames=this.layout==='single'&&this.single==='original'?this.originalFrames:this.processFrames;this.onState({time:this.time,duration:this.duration,frame:locate(frames,this.time),frames:frames.length,playing:this.playing,kind:this.kind,dimensions:this.layout==='single'&&this.single==='original'?this.source.meta:this.processDimensions});}
 request(force=false){if(!this.ready||!this.source)return;const oi=locate(this.originalFrames,this.time),pi=locate(this.processFrames,this.time),sf=this.processFrames[pi]?.i??0,key=`${oi},${pi},${this.kind},${this.configKey}`;if(!force&&key===this.lastKey)return;if(this.busy){this.queued=true;return;}this.busy=true;this.lastKey=key;this.worker.postMessage({type:'pairFrame',originalFrame:oi,processedFrame:pi,sourceFrame:sf,kind:this.kind==='original'?'render':this.kind,cfg:this.cfg,id:this.generation});}
 paint(){if(!this.bitmaps)return;const e=this.el,draw=(canvas,bitmap)=>{if(canvas.width!==bitmap.width||canvas.height!==bitmap.height){canvas.width=bitmap.width;canvas.height=bitmap.height;}const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);c.drawImage(bitmap,0,0);};
  draw(e.original,this.bitmaps.original);draw(e.processed,this.bitmaps.processed);
  e.stage.style.setProperty('--wipe',this.wipe+'%');
  if(e.framePreview){const c=e.framePreview,bitmap=this.bitmaps.processed;c.width=bitmap.width;c.height=bitmap.height;c.getContext('2d').drawImage(bitmap,0,0);}
 }
 destroy(){this.worker?.terminate();this.pause();this.resizeObserver.disconnect();this.bitmaps?.original.close();this.bitmaps?.processed.close();}
}
